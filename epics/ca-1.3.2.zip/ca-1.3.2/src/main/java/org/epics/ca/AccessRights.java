package org.epics.ca;

public enum AccessRights
{
   NO_RIGHTS,
   READ,
   WRITE,
   READ_WRITE
}
