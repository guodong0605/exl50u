package org.epics.ca.data;

public class Metadata<T> extends Data<T>
{
}