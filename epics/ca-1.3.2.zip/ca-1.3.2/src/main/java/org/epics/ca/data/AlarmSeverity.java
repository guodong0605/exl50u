package org.epics.ca.data;

public enum AlarmSeverity
{
   NO_ALARM, // 0
   MINOR_ALARM, // 1
   MAJOR_ALARM, // 2
   INVALID_ALARM // 3
}
