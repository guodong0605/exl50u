package org.epics.ca;

public enum ConnectionState
{
   NEVER_CONNECTED,
   CONNECTED,
   DISCONNECTED,
   CLOSED
}
